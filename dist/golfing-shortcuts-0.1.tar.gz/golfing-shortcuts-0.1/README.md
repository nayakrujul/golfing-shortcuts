# golfing-shortcuts
Make your code shorter with shortcuts optimised for golfing in Python
